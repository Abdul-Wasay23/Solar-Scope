﻿# SolarScope V2 - Module 3 Backup

This archive preserves the SolarScope project at the end of Module 3.

## Requirements
- Node.js
- npm

## Run the project
1. Extract this ZIP.
2. Open PowerShell in the extracted project folder.
3. Install dependencies:

   npm ci

   If package-lock.json is missing, use npm install.

4. Start development:

   npm run dev

5. Open http://localhost:3000.

## Production verification
Run npm run build, then npm run start.

## Notes
- Generated folders and dependencies are excluded.
- Configure required local environment variables if needed.
- Never share API keys, tokens or passwords.

Version: V2
Milestone: Module 3 baseline
