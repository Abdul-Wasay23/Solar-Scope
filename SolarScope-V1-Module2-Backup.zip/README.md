﻿# SolarScope V1 - Module 2 Backup

This archive preserves the Module 2 project source.

## Requirements
- Node.js
- npm

## Run locally
1. Extract the ZIP.
2. Open a terminal in the extracted folder.
3. Run npm ci.
4. Run npm run dev.
5. Open http://localhost:3000.

If package-lock.json is missing, use npm install instead.

## Production
Run npm run build, then npm run start.

## Notes
Dependencies and generated folders are excluded.
Configure any required local environment variables.
Never publish API keys or passwords.

Version: V1
Milestone: Module 2 completed
